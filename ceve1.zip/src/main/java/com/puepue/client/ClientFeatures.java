package com.puepue.client;

import java.util.ArrayDeque;
import java.util.Deque;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.Entity;
import net.minecraft.util.EnumParticleTypes;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import org.lwjgl.input.Mouse;

public class ClientFeatures {
    public static final Deque<Long> leftClicks = new ArrayDeque<Long>();
    public static final Deque<Long> rightClicks = new ArrayDeque<Long>();
    private final Minecraft mc = Minecraft.getMinecraft();

    @SubscribeEvent
    public void onAttack(AttackEntityEvent event) {
        if (event.entityPlayer == mc.thePlayer && PuepueClient.MODULES.isEnabled("Particle") && ParticleConfig.hitParticles && mc.theWorld != null) {
            Entity target = event.target;
            int amount = ParticleConfig.clampAmount(ParticleConfig.hitAmount);
            EnumParticleTypes type = ParticleConfig.TYPES[ParticleConfig.clampType(ParticleConfig.hitType)];
            for (int i = 0; i < amount; i++) {
                mc.theWorld.spawnParticle(type, target.posX, target.posY + target.height * 0.6, target.posZ,
                    (Math.random() - 0.5) * 0.35, Math.random() * 0.25, (Math.random() - 0.5) * 0.35);
            }
        }
    }

    @SubscribeEvent
    public void onMouse(InputEvent.MouseInputEvent event) {
        int button = Mouse.getEventButton();
        if (button >= 0 && Mouse.getEventButtonState()) {
            long now = System.currentTimeMillis();
            if (button == 0) leftClicks.addLast(now);
            else if (button == 1) rightClicks.addLast(now);
        }
    }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        long now = System.currentTimeMillis();
        trim(leftClicks, now); trim(rightClicks, now);
        if (mc.thePlayer == null) return;
    }

    private void trim(Deque<Long> q, long now) {
        while (!q.isEmpty() && now - q.peekFirst() > 1000L) q.removeFirst();
    }
}
