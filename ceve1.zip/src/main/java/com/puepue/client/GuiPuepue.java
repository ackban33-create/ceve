package com.puepue.client;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;
import org.lwjgl.input.Keyboard;

/** Ref-layout refresh for Puepue Client (Minecraft 1.8.9). */
public class GuiPuepue extends GuiScreen {
    private Category selected = Category.ALL;
    private ClientModule selectedModule;
    private GuiTextField search;
    private int panelX, panelY, panelW, panelH;
    private int activeTab = 0;
    private int scroll = 0;
    private boolean showQuickFps = true, showQuickPing = true, showQuickCps = true;
    private final int panel = 0xF20C0C10, card = 0xE9232329, cardOn = 0xE92C2B33;
    private final int white = 0xFFF2F2F5, muted = 0xFF9B9BA5, purple = 0xFFB49AE8;
    private static final int CARD_H = 76;

    @Override public void initGui() {
        Keyboard.enableRepeatEvents(true);
        panelW = Math.min(1120, width - 34); panelH = Math.min(550, height - 30);
        panelX = (width-panelW)/2; panelY = (height-panelH)/2;
        search = new GuiTextField(0, fontRendererObj, panelX+panelW-350, panelY+18, 230, 26);
        search.setMaxStringLength(36); search.setEnableBackgroundDrawing(false); search.setTextColor(white);
    }
    @Override public void onGuiClosed(){ Keyboard.enableRepeatEvents(false); PuepueClient.MODULES.restore(); }

    @Override public void drawScreen(int mx,int my,float pt){
        drawRect(0,0,width,height,0x8C050508);
        rounded(panelX,panelY,panelW,panelH,panel);
        // Header and top navigation
        drawRect(panelX+12,panelY+68,panelX+panelW-12,panelY+69,0x553D3D48);
        drawString(fontRendererObj,"Puepue Client",panelX+22,panelY+17,white);
        drawString(fontRendererObj,"Play better. Feel better.",panelX+22,panelY+38,muted);
        int tabsX=panelX+panelW/2-130;
        tab(tabsX,panelY+17,92,"Modules",0);
        tab(tabsX+100,panelY+17,72,"HUD",1);
        tab(tabsX+180,panelY+17,92,"Settings",2);
        tab(tabsX+280,panelY+17,88,"Profiles",3);
        rounded(panelX+panelW-260,panelY+17,210,26,0xFF19191E);
        search.drawTextBox(); if(search.getText().isEmpty())drawString(fontRendererObj,"Search modules...",panelX+panelW-244,panelY+26,muted);
        drawString(fontRendererObj,"×",panelX+panelW-28,panelY+20,white);
        drawSidebar();
        if(activeTab==0 || activeTab==1) drawCards(mx,my);
        else drawSimpleTab();
        drawRightPanel();
        super.drawScreen(mx,my,pt);
    }
    private void tab(int x,int y,int w,String label,int id){
        boolean active=activeTab==id;
        if(active) rounded(x,y,w,29,0xFF5B526E);
        drawString(fontRendererObj,label,x+12,y+10,active?white:muted);
    }
    private void drawSidebar(){
        int x=panelX+17,y=panelY+82; Category[] cats=Category.values();
        String[] icons={"▦","⚔","♧","▣","▥"};
        for(int i=0;i<cats.length;i++){
            int cy=y+i*41; boolean active=selected==cats[i];
            if(active) rounded(x,cy,136,33,0xFF4C4859);
            drawString(fontRendererObj,icons[i],x+12,cy+10,active?purple:muted);
            drawString(fontRendererObj,cats[i].label,x+35,cy+10,active?white:muted);
        }
        String[] extras={"☺ Fun","♙ Profiles","⚙ Settings"};
        for(int i=0;i<extras.length;i++)drawString(fontRendererObj,extras[i],x+12,y+cats.length*41+18+i*35,muted);
        drawRect(panelX+164,panelY+80,panelX+165,panelY+panelH-18,0x553C3C43);
        drawString(fontRendererObj,"♥  CLOSE",x+10,panelY+panelH-26,muted);
    }
    private List<ClientModule> filtered(){
        List<ClientModule> out=new ArrayList<ClientModule>();
        for(ClientModule m:PuepueClient.MODULES.all()){
            if(activeTab==1 && m.category!=Category.HUD)continue;
            if(activeTab==0 && selected!=Category.ALL && m.category!=selected)continue;
            if(!m.name.toLowerCase().contains(search.getText().toLowerCase()))continue;
            out.add(m);
        }return out;
    }
    private void drawCards(int mx,int my){
        int x=panelX+178,y=panelY+82;
        int rightW=selectedModule==null?0:236;
        int avail=panelW-198-rightW; int cols=avail>500?2:1,gap=12;
        int cw=(avail-gap*(cols-1))/cols; List<ClientModule> list=filtered();
        for(int i=0;i<list.size();i++){
            ClientModule m=list.get(i); int cx=x+(i%cols)*(cw+gap),cy=y+(i/cols)*(CARD_H+10)-scroll;
            if(cy+CARD_H<y || cy>panelY+panelH-20)continue;
            rounded(cx,cy,cw,CARD_H,m.enabled?cardOn:card);
            drawModuleIcon(m.name,cx+25,cy+20);
            drawString(fontRendererObj,m.name,cx+65,cy+17,white);
            drawString(fontRendererObj,trim(m.description,cw-94),cx+65,cy+38,muted);
            if(m.name.equals("Particle"))drawString(fontRendererObj,"•••",cx+cw-40,cy+14,purple);
            toggle(cx+cw-47,cy+48,m.enabled);
            if(mx>=cx&&mx<=cx+cw&&my>=cy&&my<=cy+CARD_H)drawRect(cx,cy+CARD_H-2,cx+cw,cy+CARD_H,0xFF8C79B5);
        }
        if(list.isEmpty())drawString(fontRendererObj,"No modules found",x+12,y+12,muted);
    }
    private void drawModuleIcon(String name,int x,int y){
        // Compact monochrome icon approximations using vanilla drawing primitives.
        int c=0xFFE6E4ED;
        if(name.contains("Bright")){drawRect(x+7,y-2,x+9,y+22,c);drawRect(x-2,y+8,x+18,y+10,c);drawRect(x+1,y+1,x+15,y+17,c);}
        else if(name.contains("Bobbing")){drawRect(x-1,y+3,x+19,y+6,c);drawRect(x+1,y+12,x+17,y+15,c);}
        else if(name.contains("Hurt")){drawRect(x+5,y+3,x+13,y+18,c);drawRect(x+1,y+7,x+17,y+14,c);}
        else if(name.contains("Particle")){drawRect(x+7,y+7,x+11,y+11,c);drawRect(x,y+2,x+4,y+6,c);drawRect(x+15,y+13,x+19,y+17,c);}
        else if(name.contains("Blur")){drawRect(x,y+2,x+18,y+4,c);drawRect(x+3,y+9,x+18,y+11,c);drawRect(x,y+16,x+14,y+18,c);}
        else if(name.contains("Counter")||name.contains("Ping")){drawRect(x,y+12,x+4,y+20,c);drawRect(x+7,y+7,x+11,y+20,c);drawRect(x+14,y+1,x+18,y+20,c);}
        else {drawRect(x+1,y+2,x+18,y+19,c);drawRect(x+4,y+5,x+15,y+16,0xFF232329);}
    }
    private void drawRightPanel(){
        int x=panelX+panelW-220,y=panelY+80,w=204;
        rounded(x,y,w,panelH-100,0xE819191D);
        if(selectedModule==null){
            drawString(fontRendererObj,"ⓘ  Client Info",x+13,y+17,white);
            drawString(fontRendererObj,"Version",x+13,y+40,muted);drawString(fontRendererObj,"1.0.0",x+w-52,y+40,white);
            drawString(fontRendererObj,"Minecraft",x+13,y+59,muted);drawString(fontRendererObj,"1.8.9",x+w-52,y+59,white);
            drawString(fontRendererObj,"Forge",x+13,y+78,muted);drawString(fontRendererObj,"11.15.1",x+w-52,y+78,white);
            drawRect(x+10,y+98,x+w-10,y+99,0x553A3A40);
            drawString(fontRendererObj,"⚡ Quick Settings",x+13,y+114,white);
            quickToggle(x+13,y+139,"Show FPS",showQuickFps);quickToggle(x+13,y+163,"Show Ping",showQuickPing);quickToggle(x+13,y+187,"Show CPS",showQuickCps);
        }else{
            drawString(fontRendererObj,"ⓘ  "+selectedModule.name,x+12,y+17,white);
            drawString(fontRendererObj,trim(selectedModule.description,w-26),x+12,y+38,muted);
            drawRect(x+10,y+60,x+w-10,y+61,0x553A3A40);
            drawString(fontRendererObj,"Module Settings",x+12,y+75,white);
            if(selectedModule.name.equals("Particle")){
                drawString(fontRendererObj,"Hit Particle",x+12,y+101,white);toggle(x+w-46,y+98,ParticleConfig.hitParticles);
                drawString(fontRendererObj,"Always Sharpness",x+12,y+125,white);toggle(x+w-46,y+122,ParticleConfig.alwaysSharpness);
                drawString(fontRendererObj,"Hit type",x+12,y+153,muted);drawString(fontRendererObj,ParticleConfig.LABELS[ParticleConfig.clampType(ParticleConfig.hitType)],x+12,y+169,purple);
                drawString(fontRendererObj,"Amount  - / +",x+12,y+192,muted);drawString(fontRendererObj,String.valueOf(ParticleConfig.hitAmount),x+w-34,y+192,white);
                drawString(fontRendererObj,"Sharpness type",x+12,y+221,muted);drawString(fontRendererObj,ParticleConfig.LABELS[ParticleConfig.clampType(ParticleConfig.sharpType)],x+12,y+237,purple);
                drawString(fontRendererObj,"Amount  - / +",x+12,y+260,muted);drawString(fontRendererObj,String.valueOf(ParticleConfig.sharpAmount),x+w-34,y+260,white);
                drawString(fontRendererObj,"Vanilla particle options",x+12,y+290,muted);drawString(fontRendererObj,"All · Smoke · Flame · Portal",x+12,y+308,muted);
            }else drawString(fontRendererObj,"No adjustable options",x+12,y+101,muted);
        }
        rounded(x+7,panelY+panelH-49,w-14,31,0xFF222227);
        drawString(fontRendererObj,"♡  Have a nice game! ♡",x+17,panelY+panelH-37,white);
    }
    private void quickToggle(int x,int y,String label,boolean state){drawString(fontRendererObj,label,x,y+4,muted);toggle(x+150,y,state);}
    private void drawSimpleTab(){int x=panelX+185,y=panelY+100;String heading=activeTab==2?"Settings": "Profiles";drawString(fontRendererObj,heading,x,y,white);drawString(fontRendererObj,activeTab==2?"Interface options will appear here.":"Default profile",x,y+25,muted);}
    private void toggle(int x,int y,boolean on){rounded(x,y,31,17,on?0xFFB9A4E8:0xFF55555D);drawRect(x+(on?17:2),y+2,x+(on?28:13),y+15,on?0xFF242229:0xFFEDEDF0);}
    private void rounded(int x,int y,int w,int h,int c){Gui.drawRect(x+4,y,x+w-4,y+h,c);Gui.drawRect(x,y+4,x+w,y+h-4,c);Gui.drawRect(x+2,y+2,x+w-2,y+h-2,c);}
    private String trim(String s,int max){while(fontRendererObj.getStringWidth(s)>max&&s.length()>3)s=s.substring(0,s.length()-4)+"...";return s;}
    @Override protected void mouseClicked(int mx,int my,int button)throws IOException{
        super.mouseClicked(mx,my,button);search.mouseClicked(mx,my,button);if(button!=0)return;
        if(mx>panelX+panelW-42&&my<panelY+65){mc.displayGuiScreen(null);return;}
        int tabsX=panelX+panelW/2-130,ty=panelY+17;
        if(mx>=tabsX&&mx<tabsX+92&&my>=ty&&my<=ty+29){activeTab=0;selectedModule=null;scroll=0;return;}
        if(mx>=tabsX+100&&mx<tabsX+172&&my>=ty&&my<=ty+29){activeTab=1;selected=Category.HUD;selectedModule=null;scroll=0;return;}
        if(mx>=tabsX+180&&mx<tabsX+272&&my>=ty&&my<=ty+29){activeTab=2;selectedModule=null;return;}
        if(mx>=tabsX+280&&mx<tabsX+368&&my>=ty&&my<=ty+29){activeTab=3;selectedModule=null;return;}
        int sx=panelX+17,sy=panelY+82;Category[] cats=Category.values();
        for(int i=0;i<cats.length;i++){int cy=sy+i*41;if(mx>=sx&&mx<=sx+136&&my>=cy&&my<=cy+33){selected=cats[i];activeTab=0;selectedModule=null;scroll=0;return;}}
        if(selectedModule!=null&&selectedModule.name.equals("Particle")&&mx>=panelX+panelW-220&&my>=panelY+80){int ry=my-(panelY+80);
            if(ry>=98&&ry<=115){ParticleConfig.hitParticles=!ParticleConfig.hitParticles;ParticleConfig.save();return;}
            if(ry>=122&&ry<=139){ParticleConfig.alwaysSharpness=!ParticleConfig.alwaysSharpness;ParticleConfig.save();return;}
            if(ry>=153&&ry<=184){ParticleConfig.hitType=(ParticleConfig.hitType+(mx>panelX+panelW-100?1:-1)+ParticleConfig.TYPES.length)%ParticleConfig.TYPES.length;ParticleConfig.save();return;}
            if(ry>=192&&ry<=211){ParticleConfig.hitAmount=ParticleConfig.clampAmount(ParticleConfig.hitAmount+(mx>panelX+panelW-100?1:-1));ParticleConfig.save();return;}
            if(ry>=221&&ry<=252){ParticleConfig.sharpType=(ParticleConfig.sharpType+(mx>panelX+panelW-100?1:-1)+ParticleConfig.TYPES.length)%ParticleConfig.TYPES.length;ParticleConfig.save();return;}
            if(ry>=260&&ry<=279){ParticleConfig.sharpAmount=ParticleConfig.clampAmount(ParticleConfig.sharpAmount+(mx>panelX+panelW-100?1:-1));ParticleConfig.save();return;}
        }
        if(selectedModule==null&&mx>=panelX+panelW-220&&my>=panelY+80){int ry=my-(panelY+80);if(ry>=139&&ry<=157){showQuickFps=!showQuickFps;return;}if(ry>=163&&ry<=181){showQuickPing=!showQuickPing;return;}if(ry>=187&&ry<=205){showQuickCps=!showQuickCps;return;}}
        if(mx>=panelX+17&&mx<=panelX+153&&my>=panelY+panelH-48){mc.displayGuiScreen(null);return;}
        int x=panelX+178,y=panelY+82,rightW=selectedModule==null?0:236,avail=panelW-198-rightW,cols=avail>500?2:1,gap=12,cw=(avail-gap*(cols-1))/cols;
        List<ClientModule> list=filtered();for(int i=0;i<list.size();i++){ClientModule m=list.get(i);int cx=x+(i%cols)*(cw+gap),cy=y+(i/cols)*(CARD_H+10)-scroll;if(mx>=cx&&mx<=cx+cw&&my>=cy&&my<=cy+CARD_H){if(m.name.equals("Particle")&&mx>=cx+cw-54&&my<=cy+30){selectedModule=m;return;}PuepueClient.MODULES.toggle(m);selectedModule=m;return;}}
    }
    @Override public void handleMouseInput() throws IOException {super.handleMouseInput();int wheel=org.lwjgl.input.Mouse.getEventDWheel();if(wheel!=0){scroll=Math.max(0,Math.min(500,scroll+(wheel>0?-42:42)));}}
    @Override protected void keyTyped(char ch,int code)throws IOException{if(code==Keyboard.KEY_ESCAPE||code==Keyboard.KEY_X){mc.displayGuiScreen(null);return;}search.textboxKeyTyped(ch,code);super.keyTyped(ch,code);}
    @Override public boolean doesGuiPauseGame(){return false;}
}
