package com.puepue.client;

public class ClientModule {
    public final String name;
    public final String description;
    public final Category category;
    public boolean enabled;

    public ClientModule(String name, String description, Category category, boolean enabled) {
        this.name = name;
        this.description = description;
        this.category = category;
        this.enabled = enabled;
    }
}
