package com.puepue.client;

import java.util.Iterator;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class HudRenderer {
    private final Minecraft mc = Minecraft.getMinecraft();
    private final int white = 0xFFF4F4F5;
    private final int muted = 0xFFBDBDC4;

    @SubscribeEvent
    public void onOverlay(RenderGameOverlayEvent.Text event) {
        if (mc.thePlayer == null || mc.theWorld == null) return;
        int x = 8, y = 8;
        if (PuepueClient.MODULES.isEnabled("FPS Counter")) {
            line("FPS  " + Minecraft.getDebugFPS(), x, y); y += 12;
        }
        if (PuepueClient.MODULES.isEnabled("CPS Counter")) {
            int l = count(ClientFeatures.leftClicks), r = count(ClientFeatures.rightClicks);
            line("CPS  " + l + " | " + r, x, y); y += 12;
        }
        if (PuepueClient.MODULES.isEnabled("MS Counter")) {
            int ping = 0;
            if (mc.getNetHandler() != null && mc.thePlayer.getUniqueID() != null) {
                NetworkPlayerInfo info = mc.getNetHandler().getPlayerInfo(mc.thePlayer.getUniqueID());
                if (info != null) ping = info.getResponseTime();
            }
            line("PING  " + ping + " ms", x, y); y += 12;
        }
        if (PuepueClient.MODULES.isEnabled("Coordinates")) {
            line(String.format("XYZ  %.1f / %.1f / %.1f", mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ), x, y);
        }
        if (PuepueClient.MODULES.isEnabled("Keystrokes")) drawKeys(8, 62);
        if (PuepueClient.MODULES.isEnabled("Armor Status")) drawArmor(8, 118);
        if (PuepueClient.MODULES.isEnabled("Potion Effects")) drawPotions(8, 155);
    }

    private int count(java.util.Deque<Long> q) { return q.size(); }

    private void line(String text, int x, int y) {
        int w = mc.fontRendererObj.getStringWidth(text) + 12;
        Gui.drawRect(x - 4, y - 3, x + w, y + 10, 0x990D0D0F);
        mc.fontRendererObj.drawStringWithShadow(text, x, y, white);
    }

    private void drawKeys(int x, int y) {
        String[] keys = {"W", "A", "S", "D"};
        int[] codes = {mc.gameSettings.keyBindForward.getKeyCode(), mc.gameSettings.keyBindLeft.getKeyCode(),
                       mc.gameSettings.keyBindBack.getKeyCode(), mc.gameSettings.keyBindRight.getKeyCode()};
        for (int i = 0; i < 4; i++) {
            int bx = x + (i == 0 ? 16 : (i == 1 ? 0 : i == 2 ? 16 : 32)) * 1;
            int by = y + (i == 0 ? 0 : 20);
            Gui.drawRect(bx, by, bx + 18, by + 18, 0xAA111115);
            mc.fontRendererObj.drawString(keys[i], bx + 5, by + 5, white);
        }
    }

    private void drawArmor(int x, int y) {
        if (mc.thePlayer == null) return;
        int slot = 0;
        for (int i = 3; i >= 0; i--) {
            net.minecraft.item.ItemStack stack = mc.thePlayer.getCurrentArmor(i);
            if (stack != null) {
                mc.getRenderItem().renderItemAndEffectIntoGUI(stack, x + slot * 20, y);
                mc.getRenderItem().renderItemOverlays(mc.fontRendererObj, stack, x + slot * 20, y);
                slot++;
            }
        }
    }

    private void drawPotions(int x, int y) {
        if (mc.thePlayer == null) return;
        int row = 0;
        for (Object obj : mc.thePlayer.getActivePotionEffects()) {
            PotionEffect effect = (PotionEffect) obj;
            Potion potion = Potion.potionTypes[effect.getPotionID()];
            if (potion == null) continue;
            String name = potion.getName();
            String time = Potion.getDurationString(effect);
            line(name + " " + time, x, y + row * 12);
            row++;
        }
    }
}
