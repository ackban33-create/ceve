package com.puepue.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.shader.Framebuffer;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

public class MotionBlur {
    private final Minecraft mc = Minecraft.getMinecraft();
    private Framebuffer prevFrame = null;

    @SubscribeEvent
    public void onOverlay(RenderGameOverlayEvent.Post event) {
        if (event.type != RenderGameOverlayEvent.ElementType.ALL) return;
        if (mc.thePlayer == null || mc.theWorld == null) return;
        if (!PuepueClient.MODULES.isEnabled("Motion Blur")) return;

        try {
            int w = mc.displayWidth;
            int h = mc.displayHeight;

            if (prevFrame == null) {
                prevFrame = new Framebuffer(w, h, true);
                prevFrame.setFramebufferColor(0, 0, 0, 0);
            } else if (prevFrame.framebufferWidth != w || prevFrame.framebufferHeight != h) {
                prevFrame.deleteFramebuffer();
                prevFrame = new Framebuffer(w, h, true);
                prevFrame.setFramebufferColor(0, 0, 0, 0);
            }

            // رسم فریم قبلی با شفافیت کم روی صفحه
            GL11.glPushMatrix();
            GL11.glEnable(GL11.GL_BLEND);
            GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
            GL11.glColor4f(1f, 1f, 1f, 0.35f);
            prevFrame.bindFramebufferTexture();
            Gui.drawScaledCustomSizeModalRect(0, 0, 0, 0, w, h, mc.displayWidth, mc.displayHeight, w, h);
            GL11.glDisable(GL11.GL_BLEND);
            GL11.glPopMatrix();

            // کپی فریم فعلی توی بافر
            prevFrame.bindFramebuffer(true);
            prevFrame.framebufferClear();
            prevFrame.unbindFramebuffer();
        } catch (Throwable t) {
            // اگه چیزی خراب شد، بی‌صدا خاموشش کن که بازی کرش نکنه
            PuepueClient.MODULES.get("Motion Blur").enabled = false;
        }
    }
}