package com.puepue.client;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.minecraft.client.Minecraft;

public class ModuleManager {
    private final List<ClientModule> modules = new ArrayList<ClientModule>();
    private float oldGamma = -1.0F;
    private boolean oldBob = true;
    private boolean bobCaptured = false;

    public ModuleManager() {
        modules.add(new ClientModule("Fullbright", "Brighten dark areas", Category.VISUAL, false));
        modules.add(new ClientModule("Minimal View Bobbing", "Reduce camera movement", Category.VISUAL, false));
        modules.add(new ClientModule("No Hurt Cam", "Disable camera shake on damage", Category.VISUAL, false));
        modules.add(new ClientModule("Particle", "Hit particles and sharpness particle options", Category.VISUAL, false));
        modules.add(new ClientModule("Motion Blur", "Subtle motion blur overlay", Category.VISUAL, false));
        modules.add(new ClientModule("CPS Counter", "Show left and right clicks", Category.HUD, true));
        modules.add(new ClientModule("MS Counter", "Show server ping", Category.HUD, true));
        modules.add(new ClientModule("FPS Counter", "Show frames per second", Category.HUD, true));
        modules.add(new ClientModule("Reach Display", "Show distance to last hit target", Category.HUD, false));
        modules.add(new ClientModule("Keystrokes", "Show movement keys", Category.HUD, false));
        modules.add(new ClientModule("Armor Status", "Show equipped armor", Category.HUD, false));
        modules.add(new ClientModule("Potion Effects", "Show active potion effects", Category.HUD, false));
        modules.add(new ClientModule("Coordinates", "Show your position", Category.HUD, false));
        modules.add(new ClientModule("Toggle Sprint", "Keep sprint enabled", Category.MOVEMENT, false));
    }

    public List<ClientModule> all() { return Collections.unmodifiableList(modules); }

    public ClientModule get(String name) {
        for (ClientModule m : modules) if (m.name.equals(name)) return m;
        return null;
    }

    public boolean isEnabled(String name) {
        ClientModule m = get(name);
        return m != null && m.enabled;
    }

    public void toggle(ClientModule module) { if (module != null) module.enabled = !module.enabled; }

    public void tick() {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer == null || mc.gameSettings == null) return;

        ClientModule fullbright = get("Fullbright");
        if (fullbright != null) {
            if (fullbright.enabled) {
                if (oldGamma < 0) oldGamma = mc.gameSettings.gammaSetting;
                mc.gameSettings.gammaSetting = 100.0F;
            } else if (oldGamma >= 0) {
                mc.gameSettings.gammaSetting = oldGamma;
                oldGamma = -1.0F;
            }
        }

        ClientModule bob = get("Minimal View Bobbing");
        if (bob != null) {
            if (bob.enabled) {
                if (!bobCaptured) {
                    oldBob = mc.gameSettings.viewBobbing;
                    bobCaptured = true;
                }
                mc.gameSettings.viewBobbing = false;
            } else if (bobCaptured) {
                mc.gameSettings.viewBobbing = oldBob;
                bobCaptured = false;
            }
        }

        if (isEnabled("Toggle Sprint")) {
            mc.thePlayer.setSprinting(mc.thePlayer.moveForward > 0.0F && !mc.thePlayer.isSneaking());
        }
    }

    public void restore() {
        Minecraft mc = Minecraft.getMinecraft();
        if (oldGamma >= 0 && mc.gameSettings != null) {
            mc.gameSettings.gammaSetting = oldGamma;
            oldGamma = -1.0F;
        }
        if (bobCaptured && mc.gameSettings != null) {
            mc.gameSettings.viewBobbing = oldBob;
            bobCaptured = false;
        }
    }
}