
package com.puepue.client;

import java.util.Random;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.util.EnumParticleTypes;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class AlwaysSharpness {

    private final Minecraft mc = Minecraft.getMinecraft();
    private final Random random = new Random();

    @SubscribeEvent
    public void onAttack(AttackEntityEvent event) {

        if (mc.thePlayer == null || mc.theWorld == null) return;
        if (event.entityPlayer != mc.thePlayer) return;
        if (!PuepueClient.MODULES.isEnabled("Particle") && ParticleConfig.alwaysSharpness) return;

        Entity target = event.target;

        if (target == null) return;

        int amount = ParticleConfig.clampAmount(ParticleConfig.sharpAmount);
        EnumParticleTypes type = ParticleConfig.TYPES[ParticleConfig.clampType(ParticleConfig.sharpType)];
        for (int i = 0; i < amount; i++) {

            double x = target.posX + (random.nextDouble() - 0.5) * target.width;
            double y = target.posY + target.height * 0.5;
            double z = target.posZ + (random.nextDouble() - 0.5) * target.width;

            double motionX = (random.nextDouble() - 0.5) * 0.2;
            double motionY = random.nextDouble() * 0.2;
            double motionZ = (random.nextDouble() - 0.5) * 0.2;

            mc.theWorld.spawnParticle(
                type,
                x, y, z,
                motionX, motionY, motionZ
            );
        }
    }
}
