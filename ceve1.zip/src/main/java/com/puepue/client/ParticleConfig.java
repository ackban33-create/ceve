package com.puepue.client;

import net.minecraft.util.EnumParticleTypes;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Properties;
import net.minecraft.client.Minecraft;

/** Settings shared by the Particle module's sub-options. */
public final class ParticleConfig {
    private ParticleConfig() {}
    public static final EnumParticleTypes[] TYPES = new EnumParticleTypes[] {
        EnumParticleTypes.CRIT, EnumParticleTypes.CRIT_MAGIC, EnumParticleTypes.HEART,
        EnumParticleTypes.FLAME, EnumParticleTypes.CLOUD, EnumParticleTypes.SMOKE_NORMAL,
        EnumParticleTypes.REDSTONE, EnumParticleTypes.ENCHANTMENT_TABLE,
        EnumParticleTypes.SPELL, EnumParticleTypes.SPELL_INSTANT, EnumParticleTypes.SPELL_WITCH,
        EnumParticleTypes.VILLAGER_HAPPY, EnumParticleTypes.VILLAGER_ANGRY, EnumParticleTypes.NOTE,
        EnumParticleTypes.PORTAL, EnumParticleTypes.FIREWORKS_SPARK, EnumParticleTypes.WATER_SPLASH,
        EnumParticleTypes.LAVA, EnumParticleTypes.SNOWBALL, EnumParticleTypes.SLIME
    };
    public static final String[] LABELS = new String[] {
        "Critical", "Magic Critical", "Heart", "Flame", "Cloud", "Smoke", "Redstone", "Enchant",
        "Spell", "Instant Spell", "Witch Spell", "Villager Happy", "Villager Angry", "Note",
        "Portal", "Firework", "Water Splash", "Lava", "Snowball", "Slime"
    };
    public static boolean hitParticles = true;
    public static boolean alwaysSharpness = false;
    public static int hitType = 0, sharpType = 1, hitAmount = 8, sharpAmount = 10;
    public static int clampType(int i) { return Math.max(0, Math.min(TYPES.length - 1, i)); }
    public static int clampAmount(int i) { return Math.max(1, Math.min(40, i)); }
    private static File file() {
        File dir = new File(Minecraft.getMinecraft().mcDataDir, "PuepueClient");
        if (!dir.exists()) dir.mkdirs();
        return new File(dir, "particles.properties");
    }
    public static void load() {
        Properties p = new Properties();
        try (FileInputStream in = new FileInputStream(file())) {
            p.load(in);
            hitParticles = Boolean.parseBoolean(p.getProperty("hitParticles", "true"));
            alwaysSharpness = Boolean.parseBoolean(p.getProperty("alwaysSharpness", "false"));
            hitType = clampType(Integer.parseInt(p.getProperty("hitType", "0")));
            sharpType = clampType(Integer.parseInt(p.getProperty("sharpType", "1")));
            hitAmount = clampAmount(Integer.parseInt(p.getProperty("hitAmount", "8")));
            sharpAmount = clampAmount(Integer.parseInt(p.getProperty("sharpAmount", "10")));
        } catch (Exception ignored) { }
    }
    public static void save() {
        Properties p = new Properties();
        p.setProperty("hitParticles", String.valueOf(hitParticles));
        p.setProperty("alwaysSharpness", String.valueOf(alwaysSharpness));
        p.setProperty("hitType", String.valueOf(hitType));
        p.setProperty("sharpType", String.valueOf(sharpType));
        p.setProperty("hitAmount", String.valueOf(hitAmount));
        p.setProperty("sharpAmount", String.valueOf(sharpAmount));
        try (FileOutputStream out = new FileOutputStream(file())) {
            p.store(out, "PuepueClient particle settings");
        } catch (Exception ignored) { }
    }
}
