package com.puepue.client;

import net.minecraft.client.Minecraft;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class NoHurtCam {
    private final Minecraft mc = Minecraft.getMinecraft();

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (mc.thePlayer == null) return;
        if (!PuepueClient.MODULES.isEnabled("No Hurt Cam")) return;

        // hurtTime باعث چرخش دوربین می‌شه — صفرش کن
        mc.thePlayer.hurtTime = 0;
        mc.thePlayer.maxHurtTime = 0;
    }
}