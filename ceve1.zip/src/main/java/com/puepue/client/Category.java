package com.puepue.client;

public enum Category {
    ALL("All"), VISUAL("Visual"), HUD("HUD"), MOVEMENT("Movement"), MISC("Misc");
    public final String label;
    Category(String label) { this.label = label; }
}
