package com.puepue.client;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class ReachDisplay {
    private final Minecraft mc = Minecraft.getMinecraft();
    private static double lastReach = 0.0;
    private static long lastReachTime = 0L;

    @SubscribeEvent
    public void onAttack(AttackEntityEvent event) {
        if (event.entityPlayer != mc.thePlayer) return;
        if (!PuepueClient.MODULES.isEnabled("Reach Display")) return;
        if (mc.theWorld == null || event.target == null) return;

        Entity target = event.target;
        // فاصله‌ی مرکز تا مرکز (مثل اکثر کلاینت‌ها)
        double dx = mc.thePlayer.posX - target.posX;
        double dy = mc.thePlayer.posY - target.posY;
        double dz = mc.thePlayer.posZ - target.posZ;
        lastReach = Math.sqrt(dx * dx + dy * dy + dz * dz);
        lastReachTime = System.currentTimeMillis();
    }

    public static double getLastReach() { return lastReach; }
    public static long getLastReachTime() { return lastReachTime; }
}