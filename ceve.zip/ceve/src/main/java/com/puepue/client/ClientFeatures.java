package com.puepue.client;

import java.util.ArrayDeque;
import java.util.Deque;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.Entity;
import net.minecraft.util.EnumParticleTypes;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import org.lwjgl.input.Mouse;

public class ClientFeatures {
    public static final Deque<Long> leftClicks = new ArrayDeque<Long>();
    public static final Deque<Long> rightClicks = new ArrayDeque<Long>();
    private final Minecraft mc = Minecraft.getMinecraft();

    @SubscribeEvent
    public void onAttack(AttackEntityEvent event) {
        if (event.entityPlayer == mc.thePlayer && PuepueClient.MODULES.isEnabled("Hit Particles") && mc.theWorld != null) {
            Entity target = event.target;
            for (int i = 0; i < 8; i++) {
                mc.theWorld.spawnParticle(EnumParticleTypes.CRIT, target.posX, target.posY + target.height * 0.6, target.posZ,
                    (mc.theRand.nextDouble() - 0.5) * 0.35, mc.theRand.nextDouble() * 0.25, (mc.theRand.nextDouble() - 0.5) * 0.35);
            }
        }
    }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        long now = System.currentTimeMillis();
        trim(leftClicks, now); trim(rightClicks, now);
        if (mc.thePlayer == null) return;
    }

    private void trim(Deque<Long> q, long now) {
        while (!q.isEmpty() && now - q.peekFirst() > 1000L) q.removeFirst();
    }
}
