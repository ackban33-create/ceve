package com.puepue.client;

import net.minecraft.client.Minecraft;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumParticleTypes;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class AlwaysSharpness {
    private final Minecraft mc = Minecraft.getMinecraft();

    @SubscribeEvent
    public void onAttack(AttackEntityEvent event) {
        if (event.entityPlayer != mc.thePlayer) return;
        if (!PuepueClient.MODULES.isEnabled("Always Sharpness")) return;
        if (mc.theWorld == null || event.target == null) return;

        ItemStack held = mc.thePlayer.getHeldItem();
        if (held == null) return;

        // اگه واقعاً Sharpness داره، وانیلا خودش پارتیکل می‌ده — دوباره نساز
        int level = EnchantmentHelper.getEnchantmentLevel(Enchantment.sharpness.effectId, held);
        if (level > 0) return;

        Entity target = event.target;
        // پارتیکل‌های مشابه Sharpness وانیلا (CRIT_MAGIC + SWEEP)
        for (int i = 0; i < 10; i++) {
            mc.theWorld.spawnParticle(
                EnumParticleTypes.CRIT_MAGIC,
                target.posX + (mc.theRand.nextDouble() - 0.5) * target.width,
                target.posY + target.height * 0.5 + (mc.theRand.nextDouble() - 0.5) * target.height * 0.5,
                target.posZ + (mc.theRand.nextDouble() - 0.5) * target.width,
                (mc.theRand.nextDouble() - 0.5) * 0.2,
                mc.theRand.nextDouble() * 0.2,
                (mc.theRand.nextDouble() - 0.5) * 0.2
            );
        }
        // یه سوئیپ هم اضافه کن که حس شمشیر بده
        mc.theWorld.spawnParticle(EnumParticleTypes.SWEEP_ATTACK,
            target.posX, target.posY + target.height * 0.5, target.posZ, 0, 0, 0);
    }
}