package com.puepue.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;

@Mod(modid = PuepueClient.MODID, name = PuepueClient.NAME, version = PuepueClient.VERSION,
     acceptedMinecraftVersions = "[1.8.9]")
public class PuepueClient {
    public static final String MODID = "puepueclient";
    public static final String NAME = "Puepue Client";
    public static final String VERSION = "1.0.0";

    public static KeyBinding openGui;
    public static final ModuleManager MODULES = new ModuleManager();
    private final Minecraft mc = Minecraft.getMinecraft();

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        openGui = new KeyBinding("Open Puepue GUI", Keyboard.KEY_X, "Puepue Client");
        ClientRegistry.registerKeyBinding(openGui);

        MinecraftForge.EVENT_BUS.register(this);
        MinecraftForge.EVENT_BUS.register(new ClientFeatures());
        MinecraftForge.EVENT_BUS.register(new HudRenderer());
        MinecraftForge.EVENT_BUS.register(new AlwaysSharpness());
        MinecraftForge.EVENT_BUS.register(new NoHurtCam());
        MinecraftForge.EVENT_BUS.register(new ReachDisplay());
        // MotionBlur موقتاً غیرفعال — بعد از سبز شدن build برمی‌گردونیم
        // MinecraftForge.EVENT_BUS.register(new MotionBlur());
    }

    @SubscribeEvent
    public void onKey(InputEvent.KeyInputEvent event) {
        if (openGui.isPressed() && mc.thePlayer != null) {
            mc.displayGuiScreen(new GuiPuepue());
        }
    }

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END || mc.thePlayer == null) return;
        MODULES.tick();
    }
}