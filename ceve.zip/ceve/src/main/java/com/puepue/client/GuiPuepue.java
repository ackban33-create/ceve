package com.puepue.client;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;
import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.input.Keyboard;

public class GuiPuepue extends GuiScreen {
    private Category selected = Category.ALL;
    private ClientModule selectedModule;
    private GuiTextField search;
    private int panelX, panelY, panelW, panelH;
    private final int bg = 0xF20D0D0F;
    private final int card = 0xFF202024;
    private final int white = 0xFFF4F4F5;
    private final int muted = 0xFFAAAAB2;
    private final int accent = 0xFFE7E7EC;

    @Override
    public void initGui() {
        Keyboard.enableRepeatEvents(true);
        panelW = Math.min(900, width - 36);
        panelH = Math.min(510, height - 36);
        panelX = (width - panelW) / 2;
        panelY = (height - panelH) / 2;
        search = new GuiTextField(0, fontRendererObj, panelX + panelW - 250, panelY + 18, 190, 24);
        search.setMaxStringLength(32);
        search.setEnableBackgroundDrawing(false);
        search.setTextColor(white);
        search.setCanLoseFocus(true);
    }

    @Override
    public void onGuiClosed() {
        Keyboard.enableRepeatEvents(false);
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        drawRect(0, 0, width, height, 0x99000000);
        drawRounded(panelX, panelY, panelW, panelH, bg);
        drawRect(panelX, panelY + 62, panelX + panelW, panelY + 63, 0xFF34343A);

        drawString(fontRendererObj, "Puepue Client", panelX + 25, panelY + 20, white);
        drawString(fontRendererObj, "PLAY BETTER. FEEL BETTER.", panelX + 25, panelY + 39, muted);
        drawRounded(panelX + panelW - 258, panelY + 17, 202, 27, 0xFF17171B);
        search.drawTextBox();
        if (search.getText().isEmpty()) drawString(fontRendererObj, "Search modules...", panelX + panelW - 240, panelY + 26, muted);
        drawString(fontRendererObj, "×", panelX + panelW - 35, panelY + 18, white);

        drawSidebar();
        drawModules(mouseX, mouseY);
        drawSettings();
        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    private void drawSidebar() {
        int sx = panelX + 16, sy = panelY + 78;
        String[] labels = {"All", "Visual", "HUD", "Movement", "Misc"};
        Category[] cats = Category.values();
        for (int i = 0; i < labels.length; i++) {
            int y = sy + i * 43;
            boolean active = selected == cats[i];
            if (active) drawRounded(sx, y, 125, 34, 0xFF45454C);
            drawString(fontRendererObj, labels[i], sx + 14, y + 12, active ? white : muted);
        }
        drawRect(panelX + 153, panelY + 76, panelX + 154, panelY + panelH - 18, 0xFF34343A);
        drawString(fontRendererObj, "X  CLOSE", panelX + 25, panelY + panelH - 28, muted);
    }

    private void drawModules(int mouseX, int mouseY) {
        int x = panelX + 174, y = panelY + 82;
        int availableW = panelW - 194 - (selectedModule == null ? 0 : 230);
        int cols = availableW > 500 ? 2 : 1;
        int gap = 10;
        int cw = (availableW - gap * (cols - 1)) / cols;
        List<ClientModule> shown = new ArrayList<ClientModule>();
        for (ClientModule m : PuepueClient.MODULES.all()) {
            if (selected != Category.ALL && m.category != selected) continue;
            if (!m.name.toLowerCase().contains(search.getText().toLowerCase())) continue;
            shown.add(m);
        }
        int ch = 65;
        for (int i = 0; i < shown.size(); i++) {
            ClientModule m = shown.get(i);
            int cx = x + (i % cols) * (cw + gap);
            int cy = y + (i / cols) * (ch + 9);
            drawRounded(cx, cy, cw, ch, m.enabled ? 0xFF303036 : card);
            drawString(fontRendererObj, m.name, cx + 13, cy + 13, white);
            drawString(fontRendererObj, trim(m.description, cw - 28), cx + 13, cy + 31, muted);
            drawToggle(cx + cw - 43, cy + 23, m.enabled);
            if (mouseX >= cx && mouseX <= cx + cw && mouseY >= cy && mouseY <= cy + ch) {
                drawRect(cx, cy + ch - 2, cx + cw, cy + ch, accent);
            }
        }
        if (shown.isEmpty()) drawString(fontRendererObj, "No modules found", x + 12, y + 12, muted);
    }

    private void drawSettings() {
        if (selectedModule == null) return;
        int x = panelX + panelW - 224, y = panelY + 82;
        drawRounded(x, y, 208, panelH - 102, 0xFF19191D);
        drawString(fontRendererObj, selectedModule.name, x + 13, y + 15, white);
        drawString(fontRendererObj, selectedModule.description, x + 13, y + 36, muted);
        drawString(fontRendererObj, "STATUS", x + 13, y + 76, muted);
        drawString(fontRendererObj, selectedModule.enabled ? "Enabled" : "Disabled", x + 13, y + 96, white);
        drawString(fontRendererObj, "Click the card to toggle", x + 13, y + 126, muted);
    }

    private void drawToggle(int x, int y, boolean on) {
        drawRounded(x, y, 30, 17, on ? 0xFFEDEDF0 : 0xFF55555D);
        drawRect(x + (on ? 16 : 2), y + 2, x + (on ? 27 : 13), y + 15, on ? 0xFF17171B : 0xFFEDEDF0);
    }

    private void drawRounded(int x, int y, int w, int h, int color) {
        // Pixel-rounded rectangle, avoiding external rendering dependencies.
        Gui.drawRect(x + 4, y, x + w - 4, y + h, color);
        Gui.drawRect(x, y + 4, x + w, y + h - 4, color);
        Gui.drawRect(x + 2, y + 2, x + w - 2, y + h - 2, color);
    }

    private String trim(String s, int max) {
        while (fontRendererObj.getStringWidth(s) > max && s.length() > 3) s = s.substring(0, s.length() - 4) + "...";
        return s;
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
        super.mouseClicked(mouseX, mouseY, mouseButton);
        search.mouseClicked(mouseX, mouseY, mouseButton);
        if (mouseButton != 0) return;
        if (mouseX > panelX + panelW - 45 && mouseY < panelY + 60) { mc.displayGuiScreen(null); return; }

        int sx = panelX + 16, sy = panelY + 78;
        Category[] cats = Category.values();
        for (int i = 0; i < cats.length; i++) {
            int y = sy + i * 43;
            if (mouseX >= sx && mouseX <= sx + 125 && mouseY >= y && mouseY <= y + 34) {
                selected = cats[i]; selectedModule = null; return;
            }
        }

        int x = panelX + 174, y = panelY + 82;
        int availableW = panelW - 194 - (selectedModule == null ? 0 : 230);
        int cols = availableW > 500 ? 2 : 1;
        int gap = 10, cw = (availableW - gap * (cols - 1)) / cols, ch = 65;
        List<ClientModule> shown = new ArrayList<ClientModule>();
        for (ClientModule m : PuepueClient.MODULES.all()) {
            if (selected != Category.ALL && m.category != selected) continue;
            if (!m.name.toLowerCase().contains(search.getText().toLowerCase())) continue;
            shown.add(m);
        }
        for (int i = 0; i < shown.size(); i++) {
            int cx = x + (i % cols) * (cw + gap), cy = y + (i / cols) * (ch + 9);
            if (mouseX >= cx && mouseX <= cx + cw && mouseY >= cy && mouseY <= cy + ch) {
                ClientModule m = shown.get(i);
                PuepueClient.MODULES.toggle(m);
                selectedModule = m;
                return;
            }
        }
    }

    @Override
    protected void keyTyped(char typedChar, int keyCode) throws IOException {
        if (keyCode == Keyboard.KEY_ESCAPE || keyCode == Keyboard.KEY_X) {
            mc.displayGuiScreen(null);
            return;
        }
        search.textboxKeyTyped(typedChar, keyCode);
        super.keyTyped(typedChar, keyCode);
    }

    @Override
    public boolean doesGuiPauseGame() { return false; }
}
